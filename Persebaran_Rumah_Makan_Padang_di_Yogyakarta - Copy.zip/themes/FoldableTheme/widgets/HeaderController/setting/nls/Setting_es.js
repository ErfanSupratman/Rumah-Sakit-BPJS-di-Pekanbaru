// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nombre",openAll:"Abrir todo en un panel",dropDown:"Mostrar en men\u00fa desplegable",noGroup:"No se ha definido ning\u00fan grupo de widgets.",groupSetLabel:"Establecer propiedades de grupos de widgets",_localized:{}}});